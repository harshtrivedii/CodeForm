class Namespace:
    def __init__(self,id,nsTitle,img,endpoint):
        self.id = id
        self.nsTitle = nsTitle
        self.img = img
        self.endpoint = endpoint
        self.rooms = []

    def addRoom(self,roomObj):
        self.rooms.append(roomObj)