import json

class Room:
    def __init__(self, roomId, roomTitle, namespace, privateRoom = False):
        self.roomId = roomId
        self.roomTitle = roomTitle
        self.namespace = namespace
        self.privateRoom = privateRoom
        self.history = []

    def addMessage(self,message):
        self.history.append(message)

    def clearHistory(self):
        self.history = []

    def getJson(self):
        data = {
            'roomId': self.roomId,
            'roomTitle' : self.roomTitle,
            'namespace' : self.namespace,
            'privateRoom' : self.privateRoom,
            'history' : self.history,
        }
        return json.dumps(data)
    