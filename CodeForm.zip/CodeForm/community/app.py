from flask import Flask, render_template,request,session
from flask_socketio import SocketIO,emit,send,rooms,join_room,leave_room
import namespaces as nasp
import json
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
namespaces = nasp.getNamespaces()
clients = {
    '/python' : {'Variables':0,'Functions':0,'Classes':0},
    '/java' : {'Variables':0,'Functions':0,'Classes':0},
    '/c' : {'Variables':0,'Functions':0,},
    '/cpp' : {'Variables':0,'Functions':0,'Classes':0}
}
messages = {
    '/python' : {'Variables':[],'Functions':[],'Classes':[]},
    '/java' : {'Variables':[],'Functions':[],'Classes':[]},
    '/c' : {'Variables':[],'Functions':[]},
    '/cpp' : {'Variables':[],'Functions':[],'Classes':[]}
}


@app.route("/community/<id>")
def home(id):
    session['username']=id
    return render_template('chat.html')

@socketio.on('connect')
def connection_handler():
    nsData = list(map((lambda ns: {'img':ns.img,'endpoint':ns.endpoint}),namespaces))
    emit('nsList',nsData)

def updateUsersInRoom(namespace,roomTitle):
    emit('updateMembers',clients[namespace][roomTitle],namespace=namespace,broadcast=True)
    print(clients)



def joinRoomHandler(roomToJoin):
    #print(request.namespace)
    if len(rooms())>1:
        roomTitle = rooms()[1]
        if roomTitle == request.sid: roomTitle=rooms()[0]
        #print(rooms()) 
        clients[request.namespace][roomTitle]-=1
        leave_room(roomTitle)
        #print(roomTitle)
        updateUsersInRoom(request.namespace, roomTitle)
    
    join_room(roomToJoin)
    #print(roomToJoin)
    clients[request.namespace][roomToJoin]+=1
    ns = list(filter((lambda ns: request.namespace[1:].lower() == ns.nsTitle.lower() ),namespaces))[0]
    nsRoom = json.loads(list(filter((lambda room: json.loads(room)['roomTitle'] == roomToJoin),ns.rooms))[0])
    emit('historyCatchUp',messages[request.namespace][nsRoom['roomTitle']])
    print(nsRoom)
    updateUsersInRoom(request.namespace,roomToJoin)
    #print(rooms())


def newMessageHandler(msg):
    print(type(msg))
    fullmsg = {
        'text' : msg['text'],
        'time' : datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'username' : session['username'],
        'avatar' : 'https://via.placeholder.com/30'
    }
    roomTitle = rooms()[1]
    if roomTitle == request.sid: roomTitle=rooms()[0]
    ns = list(filter((lambda ns: request.namespace[1:].lower() == ns.nsTitle.lower() ),namespaces))[0]
    nsRoom = json.loads(list(filter((lambda room: json.loads(room)['roomTitle'] == roomTitle),ns.rooms))[0])
    messages[request.namespace][nsRoom['roomTitle']].append(fullmsg)
    emit('messageToClients',json.dumps(fullmsg),namespace = request.namespace, room = roomTitle)


@socketio.on('connect',namespace = "/python")
def pythonNamespaceConnectionHandler():
    emit('nsRoomLoad',(namespaces[0].rooms),namespace = '/python')
    socketio.on_event('joinRoom',joinRoomHandler,namespace = '/python')
    socketio.on_event('newMessageToServer',newMessageHandler,namespace = '/python')


@socketio.on('connect',namespace = "/java")
def javaNamespaceConnectionHandler():
    emit('nsRoomLoad',(namespaces[1].rooms),namespace = "/java")
    socketio.on_event('joinRoom',joinRoomHandler,namespace = '/java')


@socketio.on('connect',namespace = "/c")
def cNamespaceConnectionHandler():
    emit('nsRoomLoad',(namespaces[2].rooms),namespace = "/c")
    socketio.on_event('joinRoom',joinRoomHandler,namespace = '/c')


@socketio.on('connect',namespace = "/cpp")
def cppNamespaceConnectionHandler():
    emit('nsRoomLoad',(namespaces[3].rooms),namespace = "/cpp")
    socketio.on_event('joinRoom',joinRoomHandler,namespace = '/cpp')







if __name__ == '__main__':
    socketio.run(app,debug=True)