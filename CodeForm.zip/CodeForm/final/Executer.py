import subprocess                   

class Executer:
    def java(self,f,input):
        p = subprocess.Popen(["javac",f],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output,error = p.communicate()
        if output : return output.decode()
        p = subprocess.Popen(["java","Main"],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if input : output,error = p.communicate(input.encode())
        else: output,error = p.communicate()
        return output.decode()

    def python(self,f,input):
        p = subprocess.Popen(["python",f], stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if input : output,error=p.communicate(input.encode())
        else: output,error=p.communicate()
        return output.decode()

    def c(self,f,input):
        p = subprocess.Popen(["gcc",f,"-o","main.exe"],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output,error = p.communicate()
        if output: return output.decode()
        p = subprocess.Popen(["main.exe"],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if input : output,error=p.communicate(input.encode())
        else: output,error=p.communicate()
        return output.decode()

    def cpp(self,f,input):
        p = subprocess.Popen(["g++",f,"-o","main.exe"],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        output,error = p.communicate()
        if output: return output.decode()
        p = subprocess.Popen(["main.exe"],stdin=subprocess.PIPE,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if input : output,error=p.communicate(input.encode())
        else: output,error=p.communicate()
        return output.decode()
