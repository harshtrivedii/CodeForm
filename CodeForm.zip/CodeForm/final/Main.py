from flask import (Flask ,request,jsonify, render_template,redirect,session,url_for)
import Executer
import psycopg2 as psy
from passlib.hash import sha256_crypt
import os
import json
import datetime
import concurrent

conn = psy.connect("dbname='oc' user='postgres' password='trivedi' host='localhost' port='5432'")
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'


@app.route("/",methods=['GET'])
def indexRoute():
    return render_template("index.html")

@app.route('/community',methods=['GET'])
def communityRoute():
    return redirect('http://localhost:5000/community/'+session['username'])



@app.route("/register",methods=['GET','POST'])
def register():
    if request.method=='POST':
        name = request.form['name']
        email = request.form['email']
        username = request.form['username']
        password = sha256_crypt.encrypt(str(request.form['password']))
        cur = conn.cursor()
        cur.execute("insert into user_details(name,email, username, password) values(%s,%s,%s,%s)",(name,email,username,password))
        conn.commit()
        return redirect(url_for("login"))
    return render_template("Register.html")


@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password_candidate = request.form['password']
        cur = conn.cursor()
        result = cur.execute("select * from user_details where username = %s",[username])
        print(result)
        if cur.rowcount > 0:
            data = cur.fetchone()
            password = data[4]
            if sha256_crypt.verify(password_candidate , password):
                session['logged_in'] = True
                session['username'] = username
                return redirect(url_for("indexRoute"))
            else:
                error = 'Invalid login'
                return "Cannot log in"
        else:
            error = 'Invalid Username'
            return error
    return render_template("login.html")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for("indexRoute"))

def executerThread(data):
    with app.app_context():
        sourceCode=data["src"]
        lang=data["lang"]
        input=data["input"]
        executer = Executer.Executer()
        if lang=="python":
            with open("temp.py","w") as f:
                f.write(sourceCode)
            output = executer.python("temp.py",input)
            return jsonify(output=output)
        if lang=="java":
            with open("Main.java","w") as f:
                f.write(sourceCode)
            output = executer.java("Main.java",input)
            return jsonify(output=output)
        if lang=="c":
            with open("main.c","w") as f:
                f.write(sourceCode)
            output = executer.c("main.c",input)
            return jsonify(output=output)
        if lang=="c++":
            with open("main.cpp","w") as f:
                f.write(sourceCode)
            output = executer.cpp("main.cpp",input)
            return jsonify(output=output,success="TRUE")

@app.route('/executer',methods=['POST'])
def execute():
    data = request.get_json()
    with concurrent.futures.ThreadPoolExecutor() as ex:
        future = ex.submit(executerThread,data)
        returnVal = future.result()
        return returnVal
   # return returnVal


@app.route('/save',methods=['POST'])
def saveFile():
    json = request.get_json()
    src = json['src']
    fileName = json['fileName']
    temp={}
    try:os.mkdir('saved/'+session['username'])
    except:pass
    with open('saved/'+session['username']+"/"+fileName,'w') as f:
        f.write(src)
    temp['name']=fileName
    temp['content']=src
    return jsonify(success="ok",responseObj=temp)


@app.route('/getSavedFiles',methods=['POST'])
def getSavedFiles():
    json = request.get_json()
    username = json['username']
    files=[]
    for r,d,f in os.walk("saved/"+username+"/"):
        for file in f:
            temp={}
            temp['name']=file
            print(temp['name'])
            temp['content']=open("saved/"+username+"/"+file,"r").readlines()
            content=''
            for line in temp['content']:
                content+=line
            temp['content']=content
            files.append(temp)
    return jsonify(files=files)


if __name__=="__main__":
    app.run(debug=True,port=5001)
    #socketio.run(app,debug=True)